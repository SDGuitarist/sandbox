---
name: content-calendar
description: Amplify workshop content calendar with posting schedule, platform timing, framework hooks, and content themes for April 2026. Use when generating posts for a specific date or looking up what is scheduled.
---

# Content Calendar

Use this skill when the user asks what content is scheduled for a specific date, or when generating posts for a particular day. It contains the full Amplify workshop content calendar.

## When to trigger
- User asks "what's scheduled for [date]?"
- User asks to "generate posts for [date]"
- User provides a date and expects platform-specific content
- User asks about posting times or content themes for a week

## Content Calendar: Amplify Workshop Promotion

### Key Dates
- Workshop Day: Saturday, April 25, 2026
- Price: $150 (early bird ended March 28)
- Platforms: Instagram, Facebook, LinkedIn

### Posting Times (Pacific)
- LinkedIn: 7:30-8:00 AM (announcements), 10:00-11:00 AM (Tue/Wed thought leadership)
- Facebook: 9:00-10:00 AM (weekdays), 9:00 AM-12:00 PM (weekends)
- Instagram: 9:00-10:00 AM (Tue-Thu), 10:00 AM-1:00 PM (Fri)

### Week 4: Trust and Depth (Apr 3-9) — "This Is Who It's For"

| Date | Platform(s) | Content Theme | Hook |
|------|-------------|---------------|------|
| Sat Apr 5 | FB, IG Stories | Behind-the-scenes prep | Casual: prepping materials |
| Tue Apr 7 | LI | "Who is this for": 3 personas | Photographer, designer, consultant |
| Tue Apr 7 | IG | "Who is this for" carousel | 5 slides, one persona per slide |
| Tue Apr 7 | FB | "Who is this for" | Tag local business groups |
| Thu Apr 9 | FB | Personal story: Dual Literacy | "AI fluency without human literacy is just automation" |
| Thu Apr 9 | LI | Capacity reframe | "You don't lack business knowledge. You lack the capacity to deploy it consistently." |

### April 11 Promo Push (Apr 6-10) — "This Saturday — Filmmakers + AI"

| Date | Platform(s) | Content Theme | Tags |
|------|-------------|---------------|------|
| Mon Apr 6 | IG, FB, IG Stories | Announcement: This Saturday | @MichaelHoward |
| Tue Apr 7 | FB | Personal story + tag blast | Film network contacts |
| Wed Apr 8 | IG, IG Stories | Framework tease + countdown | @MichaelHoward |
| Thu Apr 9 | FB, IG | Midweek push | @MichaelHoward |
| Fri Apr 10 | FB, IG, IG Stories | Tomorrow reminder | @MichaelHoward |

### Week 5: Urgency and Objections (Apr 10-16) — "Seats Are Filling"

| Date | Platform(s) | Content Theme | Hook |
|------|-------------|---------------|------|
| Sat Apr 12 | FB, LI, IG Stories | Behind-the-scenes from Apr 11 | "Ran a session yesterday with filmmakers" |
| Tue Apr 14 | ALL | Seat count update | "X seats left out of 30." Real numbers only. |
| Thu Apr 16 | IG | FAQ carousel: objection busting | "Do I need tech experience? No." |
| Thu Apr 16 | LI | The Mirror (tease) | "The real question isn't what AI can do for you." |

### Week 6: Final Countdown (Apr 17-24) — "This Is Happening"

| Date | Platform(s) | Content Theme | Hook |
|------|-------------|---------------|------|
| Fri Apr 17 | ALL | "One week away" | Venue photo, map, countdown sticker |
| Tue Apr 21 | ALL | "What to expect" walkthrough | Outline the experience |
| Fri Apr 24 | FB, IG | Night-before energy | "Tomorrow morning. Stop thinking." |

### Content Rules
1. No fabricated engagement metrics. Use actual seat numbers only.
2. One CTA per post.
3. Rotate frameworks. Don't use same concept twice in a row.
4. Match platform to content type. LinkedIn = thought leadership. Instagram = hooks and visuals. Facebook = personal stories.

### Framework Hooks (Pull from this bank)
- The Wedge: "Everyone's racing to work faster with AI. The advantage is working deeper."
- Human-Led AI: "Human at the start. AI in the middle. Human at the end."
- Expert-First Method: "The prompt isn't the art. Your expertise is the art."
- Three Questions: "Where are you irreplaceable? Where are you just doing tasks?"
- Dual Literacy: "AI fluency without human literacy is just automation."
- Counter-Narrative: "AI raises the floor. That makes the ceiling matter more."

### Workshop Details
- Title: Amplify: The Power of Human-Led AI
- Date: Saturday, April 25, 2026, 10 AM to 2 PM
- Location: Expressive Arts San Diego, 3201 Thorn St, San Diego CA 92104
- Price: $150
- Payment: Venmo @Alex-Guillen-Music / Zelle: alex.guillen.music@gmail.com
- Contact: alex@alexguillenmusic.com / 619-755-3246
- Bring: Laptop
