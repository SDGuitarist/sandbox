---
name: brand-voice-check
description: Run after drafting social media posts or written content for Alex Guillen. Checks for em-dashes, banned vocabulary, banned patterns, platform rules, CTA count, exclamation marks, and read-aloud test compliance.
---

# Brand Voice Check

Use this skill after drafting any social media post or written content for Alex Guillen. It performs a comprehensive voice and compliance check against Alex's brand rules.

## When to trigger
- After generating any Instagram, LinkedIn, or Facebook post
- After drafting email copy, workshop descriptions, or outreach messages
- When the user asks to "check the voice" or "run the voice check"

## Voice Check Process

Review the draft against ALL of the following rules. Report violations with the specific line and suggested fix.

### 1. Em-Dash Ban
Scan for any em-dash characters (—). Zero tolerance. Replace with periods, commas, or line breaks.

### 2. Banned Vocabulary (Tier 1 — Absolute Ban)
Flag any of these words: delve, tapestry, realm, leverage, utilize, harness, unlock, embark, unleash, elevate (except in workshop title "Amplify: The Power of Human-Led AI"), foster, beacon, synergy, groundbreaking, cutting-edge, unprecedented, seamless, pivotal, intricate, robust, transformative, revolutionize, supercharge, streamline, game-changer, empower, innovative, paradigm, comprehensive, bespoke, holistic, turbocharge, meticulous, multifaceted, commendable, noteworthy

### 3. Banned Phrases
Flag: "In today's fast-paced world," "It's worth noting," "In a world where," "At the end of the day," "It's important to note," "Let's dive in/dive into," "Not just X, but also Y," "In conclusion," "Moreover," "Furthermore," "Indeed," "First and foremost," "Harness the power of," "Navigate the landscape," "Deep dive," "Double down," "Transform your [noun]," "It's not just about X, it's about Y," "Passionate about," "Journey" (for products/workshops)

### 4. Banned Structural Patterns
Flag these sentence shapes even if individual words are fine:
- Cinematic setup: "In a world where..."
- False binary: "Most people do X. The few who Y..."
- Habit swap: "Stop X. Start Y."
- Triple strawman: "Not this. Not that. But this."
- FOMO framing: "If you're not doing X, you're behind"
- False revelation: "The real work is..."
- Minimalist reframe: "You don't need X. You need Y."
- Paradox era: "It's never been easier/harder"
- Unearned profundity: dramatic fragments with no setup
- Snappy triads: "Fast, efficient, and reliable" used reflexively

### 5. Hedge Words (Tier 2)
Flag unless clearly intentional: quite, rather, somewhat, arguably, seemingly, potentially, essentially, basically, certainly, literally

### 6. LinkedIn Influencer Voice (Tier 3)
Flag: "Honestly?", "Here's the breakdown," "But here's the thing," "Here's the kicker," "The bottom line"

### 7. Business Slop (Tier 5)
Flag: enable, crucial, essential, distinct, aligned/align, proactive, nuanced, intersection, elevated, agile, dynamic, best-in-class, next-generation, future-proof, scalable, tailored

### 8. Exclamation Marks
Count exclamation marks per post. Maximum: 1. Preferred: 0.

### 9. CTA Count
Each post must have exactly ONE call to action. Flag if zero or more than one.

### 10. Platform Content Match
- Instagram: Should be under 150 words. Hook-first. No stat dumps.
- LinkedIn: Data and frameworks belong here. 200-300 words.
- Facebook: Personal story. Under 200 words. No thesis statements as openers.
Flag if content doesn't match the platform.

### 11. Read-Aloud Test
Does this sound like Alex talking to a peer in a room? Or does it sound like a marketing department? Flag anything that fails this test with a specific explanation.

### 12. Stat Sourcing
Every statistic or data point must have a named source. Flag any unsourced claims.

## Output Format

```
## Voice Check Results

**PASS / FAIL** (fail if any Tier 1 violation or 3+ total violations)

### Violations Found
1. [Rule #] [Severity] — [Quote from draft] → [Suggested fix]

### Warnings
1. [Rule #] — [Quote] — [Why it's borderline]

### Clean
All other rules passed.
```
